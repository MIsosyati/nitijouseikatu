package com.example.rogapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;
import com.google.android.material.snackbar.Snackbar;
import io.realm.Realm;
import io.realm.RealmConfiguration;
import io.realm.RealmQuery;
import io.realm.RealmResults;


public class AddActivity extends AppCompatActivity {
    public Realm realm;
    EditText editText;
    EditText editText1;
    EditText editText2;
    RatingBar ratingBar;
    Spinner tagsp;
    LinearLayout linearLayout;
    ImageView imageView;
    ImageView imageView2;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        tagsp = (Spinner) findViewById(R.id.tag_spinner);
//        リルムの初期化
       Realm.init(this);
       RealmConfiguration config = new RealmConfiguration.Builder().deleteRealmIfMigrationNeeded().build();
        Realm.setDefaultConfiguration(config);
        realm = Realm.getDefaultInstance();
        linearLayout =(LinearLayout)findViewById(R.id.asu);





    }
    public void add (View V) {
        String name = editText.getText().toString();
        String place = editText1.getText().toString();
        String memo = editText2.getText().toString();
        String tag = (String) tagsp.getSelectedItem();



        //もしどっちかが空だったら
        if (name.equals("") || place.equals("")) {
            // 空なのでダメ

            if (name.equals("")) {
                linearLayout.setVisibility(View.VISIBLE);
                imageView.setVisibility(View.VISIBLE);

            }

            if (place.equals("")) {
                linearLayout.setVisibility(View.VISIBLE);
                imageView2.setVisibility(View.VISIBLE);
            }

            Snackbar.make(v, "値を入力してください", Snackbar.LENGTH_SHORT).show();
            return;
        }



        save(name, place, tag, memo);
    }


        //リルム閉じ、元の画面に戻る　またその画面の動作を終了する
        @Override
        protected void onDestroy () {
            super.onDestroy();
            realm.close();
        }

        public void save( final String name, final String place, final String tag,
        final String memo){
            realm.executeTransactionAsync(new Realm.Transaction() {
                @Override
                public void execute(Realm realm) {

                Hozon hozon = realm.createObject(Hozon.class);
                hozon.name = name;
             hozon.tag = tag;
             hozon.place = place;
             hozon.memo = memo;

                }
            }, new Realm.Transaction.OnSuccess() {
                @Override
                public void onSuccess() {
                    Toast.makeText(AddActivity.this, "保存しました", Toast.LENGTH_SHORT).show();
                    finish();

                }
            }, new Realm.Transaction.OnError() {
                @Override
                public void onError(Throwable error) {
                    Toast.makeText(AddActivity.this, "保存できませんでした", Toast.LENGTH_SHORT).show();
//                Log.w("realm", "保存失敗", error);

                }
            });
        }

}


