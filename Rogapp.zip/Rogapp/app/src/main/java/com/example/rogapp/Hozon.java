package com.example.rogapp;
import java.util.Date;

import io.realm.RealmObject;

public class  Hozon  extends RealmObject{
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getTag() {
        return tag;
    }
    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getPlace() {
        return place;
    }
    public void setPlace(String place) {
        this.place = place;
    }

    public String getMemo() {
        return memo;
    }
    public void setMemo(String memo) {
        this.memo = memo;
    }



    String name;
    String tag;
    String place;
    String memo;

}

