package com.example.rogapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import static android.icu.lang.UCharacter.GraphemeClusterBreak.V;

public class SenterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_senter);


    }
    //画面推移新規作成
    public void button(View V) {
        Intent intent = new Intent(this, AddActivity.class);
        startActivity(intent);
    }


    //画面推移新規作成
    public void button1(View V) {
        Intent intent = new Intent(this, ChoiceActivity.class);
        startActivity(intent);
    }
}



